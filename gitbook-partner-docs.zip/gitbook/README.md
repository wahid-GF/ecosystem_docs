# Partner Data Platform

**Your dataset. Your brand. Our intelligence.**

GoodFit powers your dataset with 296 attributes across 25 data blocks from 14+ live sources. You configure the data layer once — choosing which blocks, parameters, and quality thresholds matter for your market. Your customers access the result as **your data**, inside **your platform**. They use it to source accounts and enrich companies. They never see GoodFit.

***

## What your customers get

| Capability | What it does | Endpoint |
| --- | --- | --- |
| [**Account Sourcing**](data-api/account-sourcing.md) | Your customers build their TAM from your dataset. They define their market, preview qualifying companies, and receive continuously refreshed accounts. | `POST /v1/markets` |
| [**Enrichment**](data-api/enrichment.md) | Your customers pass a company and get back up to 296 attributes. Firmographics, hiring, traffic, tech, funding, reviews — from one call. | `POST /v1/enrich` |

Both capabilities draw from the same data blocks listed below. You configure the blocks once. Your customers use them as **sourcing filters** (to define which companies qualify) or receive them as **enrichment fields** (to learn everything about a company).

***

## What you configure

These blocks form your dataset. You define the parameters. Your customers query the result.

| Block | Fields | Type | Fill Rate | Source |
| --- | ---: | --- | --- | --- |
| [firmographics](data-api/firmographics.md) | 48 | Core | 95%+ | LinkedIn, Crunchbase, GoodFit NLP |
| [hiring](data-api/hiring.md) | 52 | Core | 70% | LinkedIn Jobs, Indeed |
| [team](data-api/team.md) | 37 | Core | 90%+ | LinkedIn |
| [traffic](data-api/traffic.md) | 29 | Core | 80% | Semrush |
| [website\_performance](data-api/website-performance.md) | 14 | Core | 85% | Lighthouse |
| [funding](data-api/funding.md) | 10 | Core | 40% | Crunchbase, Dealroom |
| [glassdoor](data-api/glassdoor.md) | 10 | Core | 55% | Glassdoor |
| [software](data-api/software.md) | 9 | Core | 30% | G2, Capterra |
| [team\_members](data-api/team-members.md) | 8 | You Configure | 85%+ | LinkedIn |
| [technologies](data-api/technologies.md) | 7 | You Configure | 75% | BuiltWith, SimilarTech |
| [jobs](data-api/jobs.md) | 8 | You Configure | 100% | LinkedIn Jobs, Indeed |
| [predictive\_labels](data-api/predictive-labels.md) | 3 | You Configure | 90%+ | GoodFit NLP |
| [company\_reviews](data-api/company-reviews.md) | 7 | You Configure | 100% | Trustpilot |

{% hint style="info" %}
**Core** blocks return the same fields for every company — included in your dataset by default.

**You Configure** blocks accept your parameters — keywords, countries, departments, technologies, rating filters — and return signals tailored to your configuration. Each parameter combination produces distinct data points. You set these once when building your dataset. Your customers query the result.
{% endhint %}

{% hint style="warning" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value for each field. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Figures shown are estimates across the full database; your dataset's fill rates will depend on the universe of companies you include.
{% endhint %}

***

## Data freshness

No data point older than 30 days. In practice, high-traffic entities refresh continuously. Different attributes update at different cadences depending on source availability and query frequency.

| Source | Refresh cadence |
| --- | --- |
| LinkedIn profiles | Continuous for active queries |
| LinkedIn Jobs / Indeed | Daily |
| Semrush traffic | Monthly |
| Crunchbase / Dealroom | Weekly |
| BuiltWith / SimilarTech | Weekly |
| G2 / Capterra / Trustpilot / Glassdoor | Weekly |
| Lighthouse | Monthly |
| GoodFit NLP | On crawl (continuous) |

***

## Don't see what you need?

The dataset isn't fixed. We add new blocks, fields, sources, and custom classifiers based on partner requirements.

{% content-ref url="data-api/request.md" %}
[Request a data point](data-api/request.md)
{% endcontent-ref %}
