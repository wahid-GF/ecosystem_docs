# Funding & M&A

{% hint style="info" %}
**Core** · 10 fields · Fill rate: 40% · Source: Crunchbase, Dealroom
{% endhint %}

Rounds, investors, and acquisition history.

Fill rate reflects that many companies are bootstrapped or pre-funding. Absence of funding data is itself a signal — you can filter for companies *without* funding to find bootstrapped targets.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `total_funding_amount` | Currency | 40% | Total raised |
| `last_funding_stage` | Picklist | 38% | Most recent round |
| `last_funding_date` | Date | 38% | Date of last round |
| `investors` | Multipicklist | 35% | All known investors |
| `acquisitions_count` | Number | 40% | Total acquisitions made |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "total_funding_amount": 42000000,
  "last_funding_stage": "Series B",
  "last_funding_date": "2025-09-15",
  "investors": [
    "Sequoia Capital",
    "Accel",
    "Index Ventures"
  ]
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
