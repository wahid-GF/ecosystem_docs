# Jobs (Keyword Match)

{% hint style="warning" %}
**You Configure** · 8 fields · Fill rate: 100% · Source: LinkedIn Jobs, Indeed
{% endhint %}

You define the keywords and countries. Your dataset flags companies with matching open roles. Always returns a result — `has_matches` is true or false.

***

## Your configuration

You set these parameters when building your dataset. Your customers query the result.

```json
{
  "titleKeywords": ["data engineer", "analytics"],
  "descriptionKeywords": ["dbt", "snowflake"],
  "negativeTitleKeywords": ["intern"],
  "countries": ["United States", "United Kingdom"]
}
```

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `matched_count` | Number | 100% | Open roles matching criteria |
| `matched_percentage` | Percentage | 100% | % of all roles matching |
| `has_matches` | Boolean | 100% | Whether any matches exist |
| `matched_keywords` | Multipicklist | 100% | Keywords that matched |
| `last_posted_at` | Date | varies | Most recent matching role |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "matched_count": 8,
  "matched_percentage": 0.17,
  "has_matches": true,
  "matched_keywords": [
    "data engineer",
    "analytics"
  ]
}
```

***

{% hint style="success" %}
**This is a block you configure.** You set the parameters when building your dataset — your customers never see the configuration. They query against the result as part of your sourcing filters and enrichment fields.
{% endhint %}
