# Company Reviews

{% hint style="warning" %}
**You Configure** · 7 fields · Fill rate: 100% · Source: Trustpilot
{% endhint %}

You define the keywords. Your dataset flags companies with matching Trustpilot customer reviews. Always returns a result — `has_matches` is true or false.

***

## Your configuration

You set these parameters when building your dataset. Your customers query the result.

```json
{
  "keywords": ["integration", "onboarding", "support"],
  "ratings": [1, 2, 3, 4, 5],
  "languages": ["en"]
}
```

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `matched_count` | Number | 100% | Reviews matching keywords |
| `has_matches` | Boolean | 100% | Whether matches exist |
| `min_rating` | Number | varies | Lowest matching review rating |
| `max_rating` | Number | varies | Highest matching review rating |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "matched_count": 23,
  "has_matches": true,
  "matched_keywords": [
    "integration",
    "support"
  ],
  "min_rating": 2,
  "max_rating": 5
}
```

***

{% hint style="success" %}
**This is a block you configure.** You set the parameters when building your dataset — your customers never see the configuration. They query against the result as part of your sourcing filters and enrichment fields.
{% endhint %}
