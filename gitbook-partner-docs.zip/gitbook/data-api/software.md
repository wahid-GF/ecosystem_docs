# Software Profile

{% hint style="info" %}
**Core** · 9 fields · Fill rate: 30% · Source: G2, Capterra
{% endhint %}

Product categories, reviews, demo/trial detection, and pricing page discovery.

Fill rate reflects that only software companies have G2/Capterra listings. If your dataset targets software companies specifically, effective fill rate will be significantly higher.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `categories` | Multipicklist | 30% | G2/Capterra categories |
| `has_demo_request` | Boolean | 85% | Demo offered on homepage |
| `has_trial` | Boolean | 80% | Trial offered |
| `reviews_rating` | Number | 28% | Overall review rating |
| `reviews_count` | Number | 28% | Total reviews |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "categories": [
    "Sales Engagement",
    "Revenue Intelligence"
  ],
  "has_demo_request": true,
  "reviews_rating": 4.6,
  "reviews_count": 312
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
