# Glassdoor

{% hint style="info" %}
**Core** · 10 fields · Fill rate: 55% · Source: Glassdoor
{% endhint %}

Employee sentiment signals — review ratings, CEO approval, interview experience.

Fill rate depends on company having a Glassdoor profile. Larger companies have near-100% coverage; smaller companies drop off.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `reviews_rating` | Number | 55% | Overall rating |
| `ceo_approval_percentage` | Percentage | 45% | CEO approval % |
| `recommend_to_friend_percentage` | Percentage | 45% | Recommend to friend % |
| `interviews_difficulty` | Number | 40% | Interview difficulty |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "reviews_rating": 4.1,
  "ceo_approval_percentage": 0.82,
  "interviews_difficulty": 3.2
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
