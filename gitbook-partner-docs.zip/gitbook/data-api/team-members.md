# Team Members

{% hint style="warning" %}
**You Configure** · 8 fields · Fill rate: 85%+ · Source: LinkedIn
{% endhint %}

You configure the query: departments, seniorities, countries, position keywords, minimum tenure. Your dataset returns matching employee counts per company, including extrapolated estimates for hidden LinkedIn profiles.

***

## Your configuration

You set these parameters when building your dataset. Your customers query the result.

```json
{
  "departments": ["sales", "product"],
  "seniorities": ["vp", "director"],
  "positionKeywords": ["revenue"],
  "countries": ["United States"],
  "tenureMonthsAtLeast": 6
}
```

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `matched_employee_count` | Number | 85% | Matches (extrapolated for hidden profiles) |
| `matched_employee_count_actual` | Number | 85% | Actual count without extrapolation |
| `matched_employee_percentage` | Percentage | 85% | % of total employees |
| `has_matches` | Boolean | 100% | Whether any matches exist |
| `matched_keywords` | Multipicklist | 85% | Position keywords matched |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "matched_employee_count": 5,
  "matched_employee_percentage": 0.015,
  "has_matches": true,
  "matched_keywords": [
    "VP Sales",
    "Director of Product"
  ]
}
```

***

{% hint style="success" %}
**This is a block you configure.** You set the parameters when building your dataset — your customers never see the configuration. They query against the result as part of your sourcing filters and enrichment fields.
{% endhint %}
