# Account Sourcing

**Your customers build their TAM from your dataset.**

You define the dataset — the universe of companies, the attributes that matter, the quality bar. Your customers then source accounts from that dataset using filters you've made available. They define their market, preview qualifying companies, and receive a continuously refreshed set of accounts. They never need to bring their own data, scrape LinkedIn, or burn credits on a third-party provider. The accounts come from your platform, powered by the dataset you built with GoodFit.

***

## The problem today

{% hint style="danger" %}
Today, your customers source accounts through one of three broken options:

1. **LinkedIn scraping** — grey zone, breaks constantly
2. **People Data Lab** — expensive, mediocre quality
3. **"Bring Your Own Data"** — CSVs that are stale on arrival

Every one of those options puts the burden on the customer and makes your platform feel empty on day one. Account Sourcing turns your platform into the source of truth.
{% endhint %}

***

## How it works

### 1. You build the dataset

Working with GoodFit, you define which companies are in your dataset, which attributes are included, and how Dynamic blocks are configured. This happens once (with ongoing refinement). Your customers never see this layer.

### 2. Your customer defines their market

Inside your platform, your customer specifies their ICP using the filters you've exposed — company size, geography, industry, tech stack, team composition. These map to GoodFit data block attributes behind the scenes.

### 3. They preview before committing

Before anything enters their workspace, they see: total market size, a sample of qualifying companies, and validation that their criteria make sense. No garbage lists.

### 4. Accounts flow continuously

Once published, the market is alive. New qualifying companies arrive as they enter the market. Companies that no longer qualify drop out. Your customer works a living dataset, not a static export.

***

## API reference

`POST /v1/markets`

{% tabs %}
{% tab title="Request" %}
```json
{
  "name": "Mid-Market SaaS in North America",
  "dataset": "cargo_production",
  "criteria": {
    "firmographics.employee_count": { "min": 50, "max": 500 },
    "firmographics.country": { "in": ["United States", "Canada"] },
    "firmographics.is_saas": true,
    "funding.last_funding_stage": { "in": ["Series A", "Series B"] },
    "technologies.has_matches": true,
    "hiring.open_jobs": { "min": 5 }
  }
}
```
{% endtab %}

{% tab title="Response" %}
```json
{
  "market_id": "mkt_9f3a2d",
  "dataset": "cargo_production",
  "status": "preview",
  "total_qualifying_companies": 4827,
  "sample": [
    {
      "company_id": "gf_8a2f4e",
      "domain": "acmecorp.io",
      "name": "Acme Corp",
      "employee_count": 342,
      "fit_score": 91
    },
    {
      "company_id": "gf_1b7c3d",
      "domain": "betalabs.com",
      "name": "Beta Labs",
      "employee_count": 187,
      "fit_score": 87
    }
  ],
  "refresh": {
    "new_accounts_last_30d": 247,
    "removed_last_30d": 31,
    "net_change": "+216"
  }
}
```
{% endtab %}
{% endtabs %}

***

## Available filters

Every data block can be used as a sourcing filter. Here are the most common:

| Filter | Block | Example |
| --- | --- | --- |
| Company size | `firmographics.employee_count` | `{ "min": 50, "max": 500 }` |
| Geography | `firmographics.country` | `{ "in": ["United States", "Germany"] }` |
| Business model | `firmographics.is_b2b` | `true` |
| SaaS detection | `firmographics.is_saas` | `true` |
| GTM model | `firmographics.gtm_model` | `{ "contains": "Product Led" }` |
| Funding stage | `funding.last_funding_stage` | `{ "in": ["Series A", "Series B"] }` |
| Tech stack | `technologies` | `{ "match": ["Salesforce"], "has_matches": true }` |
| Hiring activity | `hiring.open_jobs` | `{ "min": 5 }` |
| Sales team exists | `team_members` | `{ "departments": ["sales"], "has_matches": true }` |
| Job keywords | `jobs` | `{ "titleKeywords": ["data engineer"] }` |
| Traffic volume | `traffic.all_domains_visits` | `{ "min": 50000 }` |
| Predictive label | `predictive_labels` | `{ "primary_label": "Vertical SaaS" }` |

{% hint style="success" %}
**Dynamic blocks as filters are the differentiator.** No other provider lets your customers source accounts based on "companies hiring data engineers in DACH" or "companies with VP-level sales leadership." These aren't static fields — they're queries you defined when building your dataset.
{% endhint %}

***

{% hint style="info" %}
**Why this matters:** Your customer's first experience shouldn't be an empty workspace. With Account Sourcing, they describe who they sell to, and your platform delivers the accounts. Day one. Not day thirty.
{% endhint %}
