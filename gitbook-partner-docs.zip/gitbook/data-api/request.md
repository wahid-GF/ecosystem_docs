# Request a Data Point

**Don't see what you need? The dataset isn't fixed.**

We add new blocks, fields, sources, and custom classifiers based on partner requirements. Tell us what's missing and we'll scope it out.

***

## What you can request

| Request type | Description |
| --- | --- |
| **New data block** | A category of data we don't currently cover |
| **Additional fields** | More attributes within an existing block |
| **New source** | A data source we should integrate |
| **Custom NLP classifier** | A proprietary label or classification model |
| **Coverage improvement** | Better fill rates for a specific segment or region |
| **Something else** | Anything that would make the dataset more useful for you |

***

## How to submit a request

Send an email to **data-requests@goodfit.io** with the following:

### 1. What data do you need?

Be specific. Instead of "more company data", tell us something like: "We need to know which companies have a /partners or /integrations page, plus the number of listed integrations."

### 2. How would your customers use it?

This helps us understand the priority and design the right output. For example: "Our customers want to filter their TAM by companies with partner programs, and prioritise those with 50+ integrations."

### 3. Priority level

* **Nice to have** — would improve the dataset but not blocking anything
* **Important** — would meaningfully improve your product experience
* **Blocking a deal** — a customer or prospect is waiting on this

***

## What happens next

{% hint style="info" %}
We review feasibility, estimate fill rates and refresh cadence, and come back to you within **48 hours**.

If we can build it, we'll add it to your dataset — **no additional integration work on your side**. New data points appear alongside everything else in your existing sourcing and enrichment flows.
{% endhint %}

***

## Examples of past requests

These are data points that started as partner requests and are now in the platform:

* **`has_demo_request`** — a partner wanted to know which companies offer demos on their homepage. Now a field in the `software` block.
* **`predictive_labels`** — a partner needed custom company classification ("vertical SaaS", "marketplace", "agency"). Now an entire Dynamic block powered by GoodFit NLP.
* **`jobs_outside_hq_percentage`** — a partner wanted to identify companies expanding geographically. Now a field in both `hiring` and `team` blocks.
* **`gtm_model`** — a partner asked whether companies are Product-Led or Sales-Assisted. Now a proprietary NLP classification in `firmographics`.

{% hint style="success" %}
**The dataset grows based on what partners need.** If you're thinking about it, chances are other partners are too. Your request makes the platform better for everyone.
{% endhint %}
