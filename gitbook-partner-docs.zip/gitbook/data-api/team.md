# Team Composition

{% hint style="info" %}
**Core** · 37 fields · Fill rate: 90%+ · Source: LinkedIn
{% endhint %}

Department-by-department breakdown of the entire company with counts and percentages for 13 role categories. Includes 4-region geographic distribution (NA/EMEA/APAC/LATAM) and distributed workforce signals.

Where the `hiring` block shows what a company *wants* to build, the `team` block shows what they *have* today.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `sales_cnt` | Number | 88% | Sales headcount |
| `sales_percentage` | Percentage | 88% | Sales as % of total |
| `developers_cnt` | Number | 88% | Engineering headcount |
| `developers_percentage` | Percentage | 88% | Engineering as % of total |
| `people_outside_hq_percentage` | Percentage | 85% | % outside HQ |
| `na_count` | Number | 90% | North America headcount |
| `emea_count` | Number | 90% | EMEA headcount |
| `apac_count` | Number | 90% | APAC headcount |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "sales_cnt": 42,
  "sales_percentage": 0.123,
  "developers_cnt": 89,
  "people_outside_hq_percentage": 0.38,
  "na_count": 201,
  "emea_count": 98,
  "apac_count": 43
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
