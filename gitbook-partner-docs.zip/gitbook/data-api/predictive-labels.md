# Predictive Labels

{% hint style="warning" %}
**You Configure** · 3 fields · Fill rate: 90%+ · Source: GoodFit NLP
{% endhint %}

You define the labels — "marketplace", "vertical SaaS", "agency" — and GoodFit trains NLP models to classify every company from their website text. This becomes a field in your dataset.

Fill rate depends on website being crawlable. Companies without an accessible website won't have NLP classifications.

***

## Your configuration

You set these parameters when building your dataset. Your customers query the result.

```json
{
  "model": "vertical_saas_classifier"
}
```

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `primary_label` | Picklist | 90% | Best-matching label |
| `primary_label_score` | Percentage | 90% | Confidence score |
| `matched_labels` | Multipicklist | 90% | All matching labels |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "primary_label": "Vertical SaaS",
  "primary_label_score": 0.87,
  "matched_labels": [
    "Vertical SaaS",
    "B2B Platform"
  ]
}
```

***

{% hint style="success" %}
**This is a block you configure.** You set the parameters when building your dataset — your customers never see the configuration. They query against the result as part of your sourcing filters and enrichment fields.
{% endhint %}
