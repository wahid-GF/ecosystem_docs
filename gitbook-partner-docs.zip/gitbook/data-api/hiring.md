# Hiring Intelligence

{% hint style="info" %}
**Core** · 52 fields · Fill rate: 70% · Source: LinkedIn Jobs, Indeed
{% endhint %}

52 fields covering 13 department categories, geographic expansion signals, remote hiring patterns, role freshness, and hard-to-fill indicators.

Fill rate reflects companies with at least one open role. A company with zero open jobs will have null hiring data — which is itself a useful signal.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `open_jobs` | Number | 70% | Total unique open roles |
| `open_jobs_percentage` | Percentage | 70% | Open roles as % of headcount |
| `sales_cnt` | Number | 45% | Open sales roles |
| `developers_cnt` | Number | 50% | Open engineering roles |
| `remote_perc` | Percentage | 65% | % listed as remote |
| `republished_perc` | Percentage | 65% | % re-posted (hard-to-fill) |
| `jobs_outside_hq_percentage` | Percentage | 55% | % outside HQ country |
| `open_jobs_countries` | Multipicklist | 65% | Countries with openings |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "open_jobs": 47,
  "open_jobs_percentage": 0.137,
  "sales_cnt": 12,
  "remote_perc": 0.34,
  "republished_perc": 0.08,
  "jobs_outside_hq_percentage": 0.404
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
