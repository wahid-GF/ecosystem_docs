# Firmographics

{% hint style="info" %}
**Core** · 48 fields · Fill rate: 95%+ · Source: LinkedIn, Crunchbase, GoodFit NLP
{% endhint %}

The foundation block. Company identity, structure, classification, and corporate hierarchy.

Includes proprietary NLP outputs: B2B/B2C probability, SaaS detection, GTM model classification. You choose which of the 48 fields are exposed in your dataset.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `company_name` | String | 99% | Company name |
| `country` | Picklist | 97% | HQ country |
| `employee_count` | Number | 95% | Total headcount (individual, not range) |
| `revenue_range` | Picklist | 80% | Revenue range |
| `is_b2b` | Boolean | 92% | B2B classification — GoodFit NLP |
| `b2b_probability` | Percentage | 92% | B2B confidence score |
| `is_saas` | Boolean | 92% | SaaS detection — GoodFit NLP |
| `gtm_model` | Multipicklist | 88% | Product Led / Sales Assisted |
| `ipo_status` | Picklist | 70% | IPO status |
| `crunchbase_parent_org_name` | String | 35% | Parent organisation |
| `similar_companies_names` | Array | 60% | Competitors or peers |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "company_name": "Acme Corp",
  "country": "United States",
  "employee_count": 342,
  "revenue_range": "$10M-$50M",
  "is_b2b": true,
  "b2b_probability": 0.94,
  "is_saas": true,
  "gtm_model": [
    "Product Led",
    "Sales Assisted"
  ],
  "ipo_status": "Private"
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
