# Web Traffic

{% hint style="info" %}
**Core** · 29 fields · Fill rate: 80% · Source: Semrush
{% endhint %}

Monthly website visit estimates with 7-region geographic breakdown, organic/paid traffic split, and 3-month velocity trends.

Fill rate depends on domain having sufficient traffic for Semrush estimation. Very small or very new companies may not have traffic data.

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `all_domains_visits` | Number | 80% | Total visits last month |
| `organic_percentage` | Percentage | 78% | % organic traffic |
| `paid_percentage` | Percentage | 78% | % paid traffic |
| `three_months_change` | Percentage | 75% | 3-month velocity |
| `north_america_traffic_perc` | Percentage | 78% | % from North America |
| `europe_traffic_perc` | Percentage | 78% | % from Europe |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "all_domains_visits": 184200,
  "organic_percentage": 0.71,
  "three_months_change": 0.12,
  "north_america_traffic_perc": 0.58,
  "europe_traffic_perc": 0.27
}
```

***

{% hint style="info" %}
This block is included in your dataset by default. Available as both a **sourcing filter** and an **enrichment field**.
{% endhint %}
