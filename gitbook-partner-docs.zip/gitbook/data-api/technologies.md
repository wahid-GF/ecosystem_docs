# Technologies

{% hint style="warning" %}
**You Configure** · 7 fields · Fill rate: 75% · Source: BuiltWith, SimilarTech, GoodFit Crawler
{% endhint %}

You define the technology list. Your dataset tells you which companies use them. Detection combines website source code analysis with job description scanning.

***

## Your configuration

You set these parameters when building your dataset. Your customers query the result.

```json
{
  "technologies": ["Salesforce", "HubSpot", "Segment"]
}
```

***

## Schema

| Field | Type | Fill Rate | Description |
| --- | --- | --- | --- |
| `has_matches` | Boolean | 100% | Queried technologies detected |
| `technologies` | Multipicklist | 75% | Detected technologies |
| `technologies_count` | Number | 75% | Count of detected technologies |
| `detection_count` | Number | 75% | Total detections across sources |
| `last_seen_at` | Date | 75% | Most recent detection |

{% hint style="info" %}
**About fill rates:** Percentages show the proportion of companies with a non-null value. Rates vary by segment — enterprise companies tend to have higher coverage than SMBs. Your dataset's actual fill rates depend on the universe of companies you include.
{% endhint %}

***

## Example response

```json
{
  "has_matches": true,
  "technologies": [
    "Salesforce",
    "Segment"
  ],
  "technologies_count": 2,
  "detection_count": 14
}
```

***

{% hint style="success" %}
**This is a block you configure.** You set the parameters when building your dataset — your customers never see the configuration. They query against the result as part of your sourcing filters and enrichment fields.
{% endhint %}
