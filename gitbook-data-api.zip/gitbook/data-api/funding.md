# Funding & M&A

{% hint style="info" %}
**Core** · 10 fields · Source: Crunchbase, Dealroom
{% endhint %}

Funding rounds, investor lists, and acquisition history.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `total_funding_amount` | Currency | Total raised across all rounds |
| `last_funding_stage` | Picklist | Most recent round (e.g. Series B) |
| `last_funding_amount` | Currency | Amount raised in last round |
| `last_funding_date` | Date | Date of last round |
| `investors` | Multipicklist | All known investors |
| `acquisitions_names` | Array | Names of all acquisitions |
| `last_acquisition_price` | Currency | Price of last acquisition |
| `acquisitions_count` | Number | Total acquisitions made |
| `last_acquisition_name` | String | Name of last acquisition |
| `last_acquisition_date` | Date | Date of last acquisition |

***

## Example response

```json
{
  "total_funding_amount": 42000000,
  "last_funding_stage": "Series B",
  "last_funding_amount": 28000000,
  "last_funding_date": "2025-09-15",
  "investors": [
    "Sequoia Capital",
    "Accel",
    "Index Ventures"
  ],
  "acquisitions_count": 1
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
