# Web Traffic

{% hint style="info" %}
**Core** · 29 fields · Source: Semrush
{% endhint %}

Monthly website visit estimates with 7-region geographic breakdown, organic/paid traffic split, and 3-month velocity trends. Data is aggregated across all related domains and refreshed monthly.

A company with 71% organic traffic and +12% 3-month growth has a fundamentally different GTM motion than one running 80% paid with declining visits. This block makes those signals queryable.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `all_domains_visits` | Number | Total visits last month across all domains |
| `traffic_rank` | Number | Global traffic rank |
| `bounce_rate` | Percentage | Estimated bounce rate |
| `pages_per_visit` | Number | Average pages per visit |
| `avg_time_on_site` | Number | Average time per visit |
| `organic_percentage` | Percentage | % of organic traffic |
| `paid_percentage` | Percentage | % of paid traffic |
| `three_months_change` | Percentage | Traffic change over last 3 months |
| `international_traffic_perc` | Percentage | % from outside HQ country |
| `headquarter_traffic_perc` | Percentage | % from HQ country |
| `top_traffic_countries` | Multipicklist | Countries with 5%+ of traffic |
| `top_traffic_countries_count` | Number | Count of significant traffic countries |
| `top_countries_text` | String | Full country breakdown with percentages |
| `north_america_traffic_perc` | Percentage | % from North America |
| `north_america_traffic_visits` | Number | Visits from North America |
| `europe_traffic_perc` | Percentage | % from Europe |
| `europe_traffic_visits` | Number | Visits from Europe |
| `south_america_traffic_perc` | Percentage | % from South America |
| `south_america_traffic_visits` | Number | Visits from South America |
| `asia_traffic_perc` | Percentage | % from Asia |
| `asia_traffic_visits` | Number | Visits from Asia |
| `middle_east_traffic_perc` | Percentage | % from Middle East |
| `middle_east_traffic_visits` | Number | Visits from Middle East |
| `anz_traffic_perc` | Percentage | % from Australia/New Zealand |
| `anz_traffic_visits` | Number | Visits from ANZ |
| `africa_traffic_perc` | Percentage | % from Africa |
| `africa_traffic_visits` | Number | Visits from Africa |
| `other_traffic_perc` | Percentage | % from other regions |
| `other_traffic_visits` | Number | Visits from other regions |

***

## Example response

```json
{
  "all_domains_visits": 184200,
  "traffic_rank": 312847,
  "bounce_rate": 0.42,
  "organic_percentage": 0.71,
  "paid_percentage": 0.29,
  "three_months_change": 0.12,
  "north_america_traffic_perc": 0.58,
  "europe_traffic_perc": 0.27
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
