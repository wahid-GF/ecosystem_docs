# Localisations

{% hint style="info" %}
**Core** · 4 fields · Source: GoodFit Crawler
{% endhint %}

Languages and currencies detected on the company's website. A company with 8 languages and 5 currencies has a fundamentally different GTM motion than English-only.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `languages` | Multipicklist | Languages on website |
| `currencies` | Multipicklist | Currencies on pricing page |
| `languages_cnt` | Number | Language count |
| `currencies_cnt` | Number | Currency count |

***

## Example response

```json
{
  "languages": [
    "English",
    "German",
    "French",
    "Spanish"
  ],
  "currencies": [
    "USD",
    "EUR",
    "GBP"
  ],
  "languages_cnt": 4,
  "currencies_cnt": 3
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
