# Company Reviews

{% hint style="warning" %}
**Dynamic — Configurable** · 7 fields · Source: Trustpilot
{% endhint %}

Keyword-matched Trustpilot customer reviews with rating and date filters.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"keywords":["integration","onboarding","support"],"ratings":[1,2,3,4,5],"languages":["en"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_keywords` | Multipicklist | Keywords found in reviews |
| `matched_count` | Number | Count of matching reviews |
| `has_matches` | Boolean | Whether matches exist |
| `last_seen_at` | Date | Latest matching review date |
| `first_seen_at` | Date | Earliest matching review date |
| `min_rating` | Number | Lowest matching review rating |
| `max_rating` | Number | Highest matching review rating |

***

## Example response

```json
{
  "matched_count": 23,
  "has_matches": true,
  "matched_keywords": [
    "integration",
    "support"
  ],
  "min_rating": 2,
  "max_rating": 5
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
