# Account Sourcing

**Source qualified accounts. Not LinkedIn URLs.**

Your customers shouldn't need to paste a Sales Navigator URL into your product and hope for the best. Account Sourcing lets them define their market using real company attributes — headcount, tech stack, hiring patterns, funding stage, web behaviour — and receive a qualified, continuously refreshed set of accounts that match.

No scraping. No grey zones. No PDL credit burn on junk data.

***

## The problem today

{% hint style="danger" %}
Most platforms source accounts through one of three broken options:

1. **LinkedIn scraping** — unreliable, grey zone, breaks constantly
2. **People Data Lab / similar providers** — expensive, mediocre quality ("not great, but okay")
3. **"Bring Your Own Data"** — punts the problem to the customer, who stalls at onboarding

The filters aren't specific enough. The data goes stale. The customer ends up working a list they don't trust.
{% endhint %}

***

## How it works

### 1. Define the market

Your customer specifies their ICP using any combination of GoodFit's 296 data attributes — employee count, geography, B2B/B2C classification, SaaS detection, hiring velocity, tech stack, team composition, funding stage.

These aren't boolean filters on a static database. They're queries against a continuously indexed web.

### 2. Preview before committing

Before anything hits the workspace, they see:

* **Total addressable market size** — how many companies qualify
* **Browsable sample** — validate that the results make sense
* **Impact analysis** — how many net-new accounts will be added

No surprises. No garbage lists.

### 3. Publish and receive

Activate the market. GoodFit monitors the web and delivers net-new qualifying accounts as they emerge — monthly at minimum, with certain signals refreshing much faster. Companies that no longer qualify drop out automatically.

### 4. Refine as strategy evolves

Your customer's ICP will change. Maybe they're expanding to DACH. Maybe they're moving upmarket. They adjust the criteria, preview the impact, and publish — without blowing up their existing dataset.

***

## API reference

### Create a market

`POST /v1/markets`

{% tabs %}
{% tab title="Request" %}
```json
{
  "name": "Mid-Market SaaS in North America",
  "criteria": {
    "firmographics.employee_count": { "min": 50, "max": 500 },
    "firmographics.country": { "in": ["United States", "Canada"] },
    "firmographics.is_saas": true,
    "firmographics.is_b2b": true,
    "funding.last_funding_stage": { "in": ["Series A", "Series B", "Series C"] },
    "technologies": {
      "match": ["Salesforce"],
      "has_matches": true
    },
    "team_members": {
      "departments": ["sales"],
      "seniorities": ["vp", "director"],
      "has_matches": true
    },
    "hiring.open_jobs": { "min": 5 }
  }
}
```
{% endtab %}

{% tab title="Response" %}
```json
{
  "market_id": "mkt_9f3a2d",
  "name": "Mid-Market SaaS in North America",
  "status": "preview",
  "total_qualifying_companies": 4827,
  "sample": [
    {
      "company_id": "gf_8a2f4e",
      "domain": "acmecorp.io",
      "name": "Acme Corp",
      "employee_count": 342,
      "country": "United States",
      "fit_score": 91
    },
    {
      "company_id": "gf_1b7c3d",
      "domain": "betalabs.com",
      "name": "Beta Labs",
      "employee_count": 187,
      "country": "Canada",
      "fit_score": 87
    },
    {
      "company_id": "gf_4e9f2a",
      "domain": "deltaplatform.io",
      "name": "Delta Platform",
      "employee_count": 415,
      "country": "United States",
      "fit_score": 84
    }
  ],
  "refresh_summary": {
    "new_accounts_last_30d": 247,
    "removed_last_30d": 31,
    "net_change": "+216",
    "note": "5% of this market refreshed in the last 30 days"
  }
}
```
{% endtab %}
{% endtabs %}

### Publish a market

`POST /v1/markets/{market_id}/publish`

Once you've previewed and validated, publish to activate continuous monitoring.

### Update criteria

`PATCH /v1/markets/{market_id}`

Pass updated criteria. Preview the impact before republishing.

***

## Available filters

Every data block can be used as a sourcing filter. Here are the most common:

| Filter | Block | Example |
| --- | --- | --- |
| Company size | `firmographics.employee_count` | `{ "min": 50, "max": 500 }` |
| Geography | `firmographics.country` | `{ "in": ["United States", "Germany"] }` |
| Business model | `firmographics.is_b2b` | `true` |
| SaaS detection | `firmographics.is_saas` | `true` |
| GTM model | `firmographics.gtm_model` | `{ "contains": "Product Led" }` |
| Funding stage | `funding.last_funding_stage` | `{ "in": ["Series A", "Series B"] }` |
| Tech stack | `technologies` | `{ "match": ["Salesforce"], "has_matches": true }` |
| Hiring activity | `hiring.open_jobs` | `{ "min": 5 }` |
| Sales team exists | `team_members` | `{ "departments": ["sales"], "has_matches": true }` |
| Job keywords | `jobs` | `{ "titleKeywords": ["data engineer"] }` |
| Traffic volume | `traffic.all_domains_visits` | `{ "min": 50000 }` |
| Traffic trend | `traffic.three_months_change` | `{ "min": 0.1 }` |
| Predictive label | `predictive_labels` | `{ "model": "vertical_saas", "primary_label": "Vertical SaaS" }` |

{% hint style="success" %}
**Dynamic blocks as filters are the killer feature.** No other provider lets you source accounts based on "companies hiring data engineers in DACH" or "companies with VP-level sales leadership" or "companies whose Trustpilot reviews mention 'integration'." These aren't static fields — they're queries you define.
{% endhint %}

***

## Why this matters

{% hint style="info" %}
GoodFit's own TAM is approximately 10,000 companies. **500 new accounts entered that market in the last 30 days.** That's 5% additional fresh accounts every single month — accounts that didn't exist, or didn't qualify, 30 days ago.

Your customers' markets move at the same pace. Static databases miss all of them.
{% endhint %}
