# Investments

{% hint style="warning" %}
**Dynamic — Configurable** · 9 fields · Source: Crunchbase, Dealroom
{% endhint %}

For investor companies: query their investment portfolio by country, funding stage, and industry. Useful for PE/VC targeting.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"countries":[],"fundingStages":["Series A","Series B"],"crunchbaseIndustries":["Fintech"],"linkedinIndustries":[],"wasLeadInvestor":false}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `count` | Number | Investments matching criteria |
| `percentage_of_total_investments` | Percentage | % of total investments matching |
| `funding_stages` | Multipicklist | Investment stages |
| `countries` | Multipicklist | Investment countries |
| `investment_names` | Array | Investment names |
| `linked_in_industries` | Multipicklist | LinkedIn industries of investees |
| `crunchbase_industries` | Multipicklist | Crunchbase industries of investees |
| `other_investors` | Array | Co-investors |
| `last_investment_date` | Date | Last investment date |

***

## Example response

```json
{
  "count": 7,
  "percentage_of_total_investments": 0.23,
  "funding_stages": [
    "Series A",
    "Series B"
  ],
  "countries": [
    "United States",
    "United Kingdom"
  ]
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
