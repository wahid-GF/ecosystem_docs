# Team Composition

{% hint style="info" %}
**Core** · 37 fields · Source: LinkedIn
{% endhint %}

Department-by-department breakdown of the entire company, with both counts and percentages for 13 role categories. Includes 4-region geographic distribution (NA/EMEA/APAC/LATAM) and distributed workforce signals.

Where the `hiring` block shows what a company *wants* to build, the `team` block shows what they *have* today.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `primary_location_country` | Picklist | Country where most employees are located |
| `countries` | Multipicklist | All countries with employees |
| `success_cnt` | Number | Success team headcount |
| `success_percentage` | Percentage | Success as % of total |
| `sales_cnt` | Number | Sales headcount |
| `sales_percentage` | Percentage | Sales as % of total |
| `recruitment_cnt` | Number | Recruitment headcount |
| `recruitment_percentage` | Percentage | Recruitment as % of total |
| `product_cnt` | Number | Product headcount |
| `product_percentage` | Percentage | Product as % of total |
| `procurement_cnt` | Number | Procurement headcount |
| `procurement_percentage` | Percentage | Procurement as % of total |
| `operations_cnt` | Number | Operations headcount |
| `operations_percentage` | Percentage | Operations as % of total |
| `marketing_cnt` | Number | Marketing headcount |
| `marketing_percentage` | Percentage | Marketing as % of total |
| `hr_cnt` | Number | HR headcount |
| `hr_percentage` | Percentage | HR as % of total |
| `finance_cnt` | Number | Finance headcount |
| `finance_percentage` | Percentage | Finance as % of total |
| `developers_cnt` | Number | Engineering headcount |
| `developers_percentage` | Percentage | Engineering as % of total |
| `customer_service_cnt` | Number | Customer Service headcount |
| `customer_service_percentage` | Percentage | CS as % of total |
| `commercial_cnt` | Number | Commercial headcount |
| `commercial_percentage` | Percentage | Commercial as % of total |
| `countries_outside_of_office_locations` | Multipicklist | Countries with people outside office locations |
| `countries_outside_of_office_locations_count` | Number | Count of countries outside offices |
| `people_outside_of_office_locations_count` | Number | People outside office locations |
| `people_outside_of_office_locations_percentage` | Percentage | % outside office locations |
| `people_outside_hq_count` | Number | People outside HQ country |
| `people_outside_hq_percentage` | Percentage | % outside HQ country |
| `na_count` | Number | North America headcount |
| `emea_count` | Number | EMEA headcount |
| `apac_count` | Number | APAC headcount |
| `latam_count` | Number | LATAM headcount |
| `people_by_country_count_text` | String | Full country breakdown with counts and percentages |

***

## Example response

```json
{
  "sales_cnt": 42,
  "sales_percentage": 0.123,
  "developers_cnt": 89,
  "developers_percentage": 0.26,
  "people_outside_hq_percentage": 0.38,
  "na_count": 201,
  "emea_count": 98,
  "apac_count": 43,
  "latam_count": 0
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
