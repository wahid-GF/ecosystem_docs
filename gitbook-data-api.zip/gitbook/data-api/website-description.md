# Website Description

{% hint style="warning" %}
**Dynamic — Configurable** · 2 fields · Source: GoodFit Crawler
{% endhint %}

Keyword match against the website's meta description.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"keywords":["compliance","security","enterprise"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_keywords` | Multipicklist | Keywords matched |
| `has_matches` | Boolean | Whether matches exist |

***

## Example response

```json
{
  "matched_keywords": [
    "enterprise"
  ],
  "has_matches": true
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
