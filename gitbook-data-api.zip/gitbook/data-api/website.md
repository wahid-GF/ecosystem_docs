# Website

{% hint style="info" %}
**Core** · 3 fields · Source: GoodFit Crawler
{% endhint %}

Basic website metadata — description, careers page, blog detection.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `description` | String | Meta website description |
| `careers_url` | String | Careers page URL |
| `has_blog` | Boolean | Whether website has a blog |

***

## Example response

```json
{
  "description": "Acme Corp helps B2B teams close deals faster.",
  "careers_url": "https://acmecorp.io/careers",
  "has_blog": true
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
