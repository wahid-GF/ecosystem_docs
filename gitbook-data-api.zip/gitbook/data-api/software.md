# Software Profile

{% hint style="info" %}
**Core** · 9 fields · Source: G2, Capterra
{% endhint %}

Product categories, reviews, demo/trial detection, and pricing page discovery from G2 and Capterra.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `has_demo_request` | Boolean | Demo offered on homepage |
| `has_trial` | Boolean | Trial offered on homepage |
| `sub_categories` | Multipicklist | Sub-categories from G2/Capterra |
| `categories` | Multipicklist | Categories from G2/Capterra |
| `url` | String | Product profile URL |
| `pricing_url` | String | Pricing page URL |
| `reviews_rating` | Number | Overall review rating |
| `reviews_count` | Number | Total review count |
| `product_count` | Number | Product count on G2/Capterra |

***

## Example response

```json
{
  "categories": [
    "Sales Engagement",
    "Revenue Intelligence"
  ],
  "has_demo_request": true,
  "has_trial": false,
  "reviews_rating": 4.6,
  "reviews_count": 312
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
