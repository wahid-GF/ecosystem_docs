# Firmographics

{% hint style="info" %}
**Core** · 48 fields · Source: LinkedIn, Crunchbase, GoodFit NLP
{% endhint %}

The foundation block. Company identity, structure, classification, and corporate hierarchy — sourced from LinkedIn, Crunchbase, and GoodFit's proprietary NLP models.

This is the block you'll query most often. It contains the fields that define *what* a company is: name, location, size, revenue, business model, GTM approach, IPO status, parent/child relationships, and competitive peers.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `company_id` | String | Unique record identifier |
| `primary_domain` | String | Main website domain |
| `company_name` | String | Company name as listed on LinkedIn |
| `country` | Picklist | HQ country sourced from LinkedIn |
| `state` | Picklist | If US-based, state sourced from LinkedIn |
| `city` | String | HQ city sourced from LinkedIn |
| `street` | String | HQ street sourced from LinkedIn |
| `region` | Picklist | HQ region sourced from LinkedIn |
| `continent` | Picklist | HQ continent sourced from LinkedIn |
| `employee_count` | Number | Total employee count from LinkedIn (individual count, not range) |
| `employee_range` | Picklist | Employee range as reported on LinkedIn |
| `revenue_range` | Picklist | Revenue range estimated by GoodFit |
| `company_type` | Picklist | Company type sourced from LinkedIn |
| `linked_in_industry` | Picklist | Top-level industry as listed on LinkedIn |
| `crunchbase_industries` | Multipicklist | Industries sourced from Crunchbase |
| `is_b2b` | Boolean | B2B classification — GoodFit NLP model |
| `is_b2c` | Boolean | B2C classification — GoodFit NLP model |
| `b2b_probability` | Percentage | B2B confidence score — GoodFit NLP model |
| `b2c_probability` | Percentage | B2C confidence score — GoodFit NLP model |
| `is_ecommerce` | Boolean | Ecommerce classification — GoodFit NLP model |
| `target_user` | Multipicklist | B2B/B2C labelling from GoodFit NLP |
| `is_saas` | Boolean | SaaS detection — GoodFit NLP model |
| `is_technology` | Boolean | Technology company classification — GoodFit NLP model |
| `gtm_model` | Multipicklist | Product Led / Sales Assisted — GoodFit NLP model |
| `year_founded` | Number | Year founded as listed on LinkedIn |
| `linkedin_followers` | Number | Count of LinkedIn followers |
| `linked_in_id` | String | LinkedIn profile ID |
| `linked_in_url` | String | LinkedIn profile URL |
| `linked_in_description` | String | Company's LinkedIn 'About Us' description |
| `linked_in_specialties` | Array | Specialties as listed on LinkedIn |
| `linked_in_unclaimed` | Boolean | Whether LinkedIn profile is unclaimed |
| `related_domains` | Array | Domains associated with the company |
| `domain_is_active` | Boolean | Whether primary domain is active |
| `is_active` | Boolean | Whether company has an active LinkedIn profile |
| `office_location_countries` | Multipicklist | Office countries from Glassdoor + LinkedIn |
| `office_location_countries_cnt` | Number | Count of office countries |
| `crunchbase_url` | String | Crunchbase profile URL |
| `crunchbase_also_known_as` | String | Alternative company name from Crunchbase |
| `crunchbase_legal_name` | String | Legal company name from Crunchbase |
| `crunchbase_parent_org_name` | String | Parent organisation name from Crunchbase |
| `crunchbase_children_org_names` | Array | Subsidiary names from Crunchbase |
| `crunchbase_rank` | Number | Crunchbase rank |
| `crunchbase_description` | String | Company description from Crunchbase |
| `ipo_status` | Picklist | IPO status from Crunchbase |
| `stock_symbol` | String | Stock symbol from Crunchbase |
| `acquired_by_name` | String | Acquirer company name |
| `crunchbase_acquired_by_url` | String | Acquirer's Crunchbase URL |
| `similar_companies_names` | Array | Names of competitors or peers |
| `similar_companies_urls` | Array | LinkedIn URLs of competitors or peers |

***

## Example response

```json
{
  "company_id": "gf_8a2f4e",
  "primary_domain": "acmecorp.io",
  "company_name": "Acme Corp",
  "country": "United States",
  "employee_count": 342,
  "revenue_range": "$10M-$50M",
  "is_b2b": true,
  "is_b2c": false,
  "b2b_probability": 0.94,
  "is_saas": true,
  "gtm_model": [
    "Product Led",
    "Sales Assisted"
  ],
  "ipo_status": "Private",
  "crunchbase_parent_org_name": null,
  "similar_companies_names": [
    "RivalTech",
    "CompeteCo"
  ]
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
