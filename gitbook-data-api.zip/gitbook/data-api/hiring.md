# Hiring Intelligence

{% hint style="info" %}
**Core** · 52 fields · Source: LinkedIn Jobs, Indeed
{% endhint %}

The deepest hiring data available in a single block. 52 fields covering 13 department categories, geographic expansion signals, remote hiring patterns, role freshness, and hard-to-fill indicators.

A company that just went from 2 sales reps to 12 in 3 months, with 40% of new hires outside HQ, is a completely different prospect than a static 200-person company. This block makes that distinction automatically.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `has_success` | Boolean | Hiring for Customer Success roles |
| `has_sales` | Boolean | Hiring for Sales roles |
| `has_recruitment` | Boolean | Hiring for Recruitment roles |
| `has_product` | Boolean | Hiring for Product roles |
| `has_procurement` | Boolean | Hiring for Procurement roles |
| `has_operations` | Boolean | Hiring for Operations roles |
| `has_marketing` | Boolean | Hiring for Marketing roles |
| `has_hr` | Boolean | Hiring for HR roles |
| `has_finance` | Boolean | Hiring for Finance roles |
| `has_developers` | Boolean | Hiring for Engineering roles |
| `has_customer_service` | Boolean | Hiring for Customer Service roles |
| `has_commercial` | Boolean | Hiring for Commercial roles |
| `role_categories` | Multipicklist | Active role categories |
| `open_jobs` | Number | Total unique open roles |
| `open_jobs_percentage` | Percentage | Open roles as % of total headcount |
| `open_jobs_in_last_3_months` | Number | Roles opened in last 3 months |
| `open_jobs_countries` | Multipicklist | Countries with openings |
| `open_jobs_countries_count` | Number | Count of countries with openings |
| `jobs_by_country_count_text` | String | Country breakdown with counts and percentages |
| `success_cnt` | Number | Success role count |
| `success_percentage` | Percentage | Success role % |
| `sales_cnt` | Number | Sales role count |
| `sales_percentage` | Percentage | Sales role % |
| `recruitment_cnt` | Number | Recruitment role count |
| `recruitment_percentage` | Percentage | Recruitment role % |
| `product_cnt` | Number | Product role count |
| `product_percentage` | Percentage | Product role % |
| `procurement_cnt` | Number | Procurement role count |
| `procurement_percentage` | Percentage | Procurement role % |
| `operations_cnt` | Number | Operations role count |
| `operations_percentage` | Percentage | Operations role % |
| `marketing_cnt` | Number | Marketing role count |
| `marketing_percentage` | Percentage | Marketing role % |
| `hr_cnt` | Number | HR role count |
| `hr_percentage` | Percentage | HR role % |
| `finance_cnt` | Number | Finance role count |
| `finance_percentage` | Percentage | Finance role % |
| `developers_cnt` | Number | Engineering role count |
| `developers_percentage` | Percentage | Engineering role % |
| `customer_service_cnt` | Number | Customer Service role count |
| `customer_service_percentage` | Percentage | Customer Service role % |
| `commercial_cnt` | Number | Commercial role count |
| `commercial_percentage` | Percentage | Commercial role % |
| `older_jobs_count` | Number | Roles open longer than 30 days |
| `older_jobs_percentage` | Percentage | % of roles older than 30 days |
| `remote_count` | Number | Remote roles count |
| `remote_perc` | Percentage | % of roles listed as remote |
| `republished_perc` | Percentage | % of roles re-posted (hard-to-fill signal) |
| `countries_outside_of_office_locations` | Multipicklist | Countries with jobs outside office locations |
| `countries_outside_of_office_locations_count` | Number | Count of countries outside office locations |
| `jobs_outside_of_office_locations_count` | Number | Jobs outside office locations |
| `jobs_outside_of_office_locations_percentage` | Percentage | % of jobs outside office locations |
| `jobs_outside_hq_count` | Number | Jobs outside HQ country |
| `jobs_outside_hq_percentage` | Percentage | % of jobs outside HQ country |

***

## Example response

```json
{
  "open_jobs": 47,
  "open_jobs_percentage": 0.137,
  "has_sales": true,
  "has_developers": true,
  "sales_cnt": 12,
  "sales_percentage": 0.255,
  "remote_perc": 0.34,
  "republished_perc": 0.08,
  "older_jobs_percentage": 0.21,
  "jobs_outside_hq_count": 19,
  "jobs_outside_hq_percentage": 0.404
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
