# Domain Elements

{% hint style="warning" %}
**Dynamic — Configurable** · 9 fields · Source: GoodFit Crawler
{% endhint %}

Detect specific page elements (CTAs, forms, badges, widgets) on a company's website by keyword.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"elementKeywords":["demo request","book a call","free trial"],"types":[]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_elements` | Multipicklist | Page elements discovered |
| `matched_elements_count` | Number | Count of elements |
| `matched_keywords` | Multipicklist | Keywords found |
| `sample_url` | String | Shortest URL with match |
| `urls` | Array | All URLs with matches |
| `urls_count` | Number | Count of URLs |
| `has_matches` | Boolean | Whether matches exist |
| `last_seen_at` | Date | Last detected |
| `first_seen_at` | Date | First detected |

***

## Example response

```json
{
  "has_matches": true,
  "matched_elements": [
    "demo request",
    "book a call"
  ],
  "matched_elements_count": 2,
  "sample_url": "https://acmecorp.io"
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
