# Software Features

{% hint style="warning" %}
**Dynamic — Configurable** · 4 fields · Source: G2, Capterra
{% endhint %}

Search a company's listed product features by keyword.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"keywords":["SSO","SAML","API"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_keywords` | Multipicklist | Keywords matching features |
| `has_matches` | Boolean | Whether matching features exist |
| `matched_features` | Multipicklist | Features with keyword match |
| `matched_features_count` | Number | Count of matching features |

***

## Example response

```json
{
  "has_matches": true,
  "matched_features": [
    "SSO Integration",
    "REST API",
    "SAML Authentication"
  ],
  "matched_features_count": 3
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
