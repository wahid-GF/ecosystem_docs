# Team Members

{% hint style="warning" %}
**Dynamic — Configurable** · 8 fields · Source: LinkedIn
{% endhint %}

Query specific people within a company by department, seniority, country, position keyword, and tenure length. Returns both actual LinkedIn counts and extrapolated estimates that account for hidden profiles.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"countries":["United States"],"departments":["sales","product"],"seniorities":["vp","director"],"positionKeywords":["revenue"],"tenureMonthsAtLeast":6}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_employee_count` | Number | Count of matching employees (extrapolated for hidden profiles) |
| `matched_employee_count_actual` | Number | Actual count without extrapolation |
| `matched_employee_percentage` | Percentage | % of total employees matching |
| `has_matches` | Boolean | Whether any matching employees exist |
| `matched_countries` | Multipicklist | Countries where matches are located |
| `matched_countries_count` | Number | Count of countries with matches |
| `matched_keywords` | Multipicklist | Position keywords that matched |
| `example_employee_url` | String | Sample LinkedIn profile URL |

***

## Example response

```json
{
  "matched_employee_count": 5,
  "matched_employee_count_actual": 4,
  "matched_employee_percentage": 0.015,
  "has_matches": true,
  "matched_countries": [
    "United States"
  ],
  "matched_keywords": [
    "VP Sales",
    "Director of Product"
  ]
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
