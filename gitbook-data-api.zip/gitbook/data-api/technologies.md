# Technologies

{% hint style="warning" %}
**Dynamic — Configurable** · 7 fields · Source: BuiltWith, SimilarTech, GoodFit Crawler
{% endhint %}

Detect specific technologies used by a company via website source code analysis and job description scanning. Pass any technology names and receive detection results with timestamps and evidence URLs.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"technologies":["Salesforce","HubSpot","Segment"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `has_matches` | Boolean | Whether any queried technologies were detected |
| `technologies` | Multipicklist | List of detected technologies |
| `technologies_count` | Number | Count of detected technologies |
| `sample_url` | String | Latest URL where technology was detected |
| `last_seen_at` | Date | Most recent detection date |
| `urls` | Array | All URLs where technologies were detected |
| `detection_count` | Number | Total detection instances across all sources |

***

## Example response

```json
{
  "has_matches": true,
  "technologies": [
    "Salesforce",
    "Segment"
  ],
  "technologies_count": 2,
  "detection_count": 14,
  "last_seen_at": "2026-02-10"
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
