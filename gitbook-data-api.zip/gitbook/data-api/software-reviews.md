# Software Reviews

{% hint style="warning" %}
**Dynamic — Configurable** · 7 fields · Source: G2
{% endhint %}

Keyword-matched G2 reviews with positive and negative keyword filters.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"positiveKeywords":["easy to use","fast support"],"negativeKeywords":["slow","buggy"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_keywords` | Multipicklist | Keywords found in reviews |
| `matched_count` | Number | Count of matching reviews |
| `has_matches` | Boolean | Whether matching reviews exist |
| `sample_url` | String | URL of latest matching review |
| `urls` | Array | All matching review URLs |
| `last_seen_at` | Date | Date of latest matching review |
| `first_seen_at` | Date | Date of earliest matching review |

***

## Example response

```json
{
  "matched_count": 14,
  "has_matches": true,
  "matched_keywords": [
    "easy to use"
  ],
  "last_seen_at": "2026-01-28"
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
