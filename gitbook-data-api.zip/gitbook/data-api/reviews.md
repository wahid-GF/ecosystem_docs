# Reviews (Trustpilot)

{% hint style="info" %}
**Core** · 3 fields · Source: Trustpilot
{% endhint %}

Overall Trustpilot review profile — languages, rating, count.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `languages` | Multipicklist | Review languages |
| `rating` | Number | Overall rating |
| `count` | Number | Total review count |

***

## Example response

```json
{
  "rating": 4.3,
  "count": 847,
  "languages": [
    "en",
    "de",
    "fr"
  ]
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
