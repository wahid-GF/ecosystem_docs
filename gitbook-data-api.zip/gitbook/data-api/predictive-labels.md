# Predictive Labels

{% hint style="warning" %}
**Dynamic — Configurable** · 3 fields · Source: GoodFit NLP
{% endhint %}

GoodFit's proprietary NLP classification system. Define your own labels — "marketplace", "vertical SaaS", "agency" — and GoodFit trains models to classify every company from their website text.

This is the block that no third-party database can replicate. The models read actual website content and learn to classify companies against customer-defined taxonomies.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"model":"vertical_saas_classifier"}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `primary_label` | Picklist | Best-matching label for this model |
| `primary_label_score` | Percentage | Confidence score for primary label |
| `matched_labels` | Multipicklist | All labels matching this company |

***

## Example response

```json
{
  "primary_label": "Vertical SaaS",
  "primary_label_score": 0.87,
  "matched_labels": [
    "Vertical SaaS",
    "B2B Platform"
  ]
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
