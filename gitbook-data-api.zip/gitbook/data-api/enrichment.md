# Enrichment

**Fill in everything that's missing. From one integration.**

Your customers have accounts in their CRM, in their product analytics, in their spreadsheets. What they don't have is the data they need to actually work those accounts — who's on the buying committee, what tech they're running, whether they're growing or contracting, what their GTM model looks like.

Enrichment takes any company and returns up to 296 attributes across 25 data categories, from a single API call.

***

## The problem today

{% hint style="danger" %}
The current options are broken:

* **Apollo** shut down partner access — anyone they see as a competitor lost their integration
* **People Data Lab** charges a fortune for data that customers describe as "okay, not great"
* **LinkedIn scraping** is a grey zone that breaks constantly
* **None of them** can tell you whether a company is Product-Led or Sales-Assisted, because that requires actually reading the website — which only GoodFit does

Your customers end up stitching together 3-5 data vendors, paying for overlapping coverage, and still missing the signals that matter most.
{% endhint %}

***

## How it works

### 1. Pass a domain or company ID

That's it. One identifier. You don't need to pre-match, deduplicate, or normalise. GoodFit resolves the entity and pulls from all available sources.

### 2. Choose your blocks

Request all 25 data blocks, or just the ones you need. For **Dynamic** blocks (technologies, jobs, team\_members, reviews), pass your customer's specific parameters — keywords, departments, countries. Each configuration returns tailored signals.

### 3. Receive structured data

Every field is typed, sourced, and timestamped. No mystery data. No "we aggregate from multiple sources" hand-waving. You know exactly where every data point comes from.

### 4. Keep it fresh

Batch enrich on a schedule, or subscribe to webhooks for real-time updates when data changes. No data point older than 30 days. High-traffic entities refresh continuously.

***

## API reference

### Enrich a company

`POST /v1/enrich`

{% tabs %}
{% tab title="Request" %}
```json
{
  "domain": "acmecorp.io",
  "blocks": [
    "firmographics",
    "hiring",
    "team",
    "traffic",
    "technologies",
    "funding",
    "software"
  ],
  "dynamic_config": {
    "technologies": {
      "technologies": ["Salesforce", "HubSpot", "Segment"]
    },
    "team_members": {
      "departments": ["sales", "product"],
      "seniorities": ["vp", "director"],
      "countries": ["United States"]
    }
  }
}
```
{% endtab %}

{% tab title="Response" %}
```json
{
  "company_id": "gf_8a2f4e",
  "domain": "acmecorp.io",
  "enriched_at": "2026-02-18T09:14:22Z",
  "blocks_returned": 7,
  "firmographics": {
    "company_name": "Acme Corp",
    "country": "United States",
    "employee_count": 342,
    "revenue_range": "$10M-$50M",
    "is_saas": true,
    "is_b2b": true,
    "b2b_probability": 0.94,
    "gtm_model": ["Product Led", "Sales Assisted"],
    "is_technology": true,
    "year_founded": 2018
  },
  "hiring": {
    "open_jobs": 47,
    "open_jobs_percentage": 0.137,
    "sales_cnt": 12,
    "developers_cnt": 18,
    "remote_perc": 0.34,
    "republished_perc": 0.08,
    "jobs_outside_hq_percentage": 0.404,
    "open_jobs_countries": ["US", "UK", "DE", "IN"]
  },
  "team": {
    "sales_cnt": 42,
    "sales_percentage": 0.123,
    "developers_cnt": 89,
    "people_outside_hq_percentage": 0.38,
    "na_count": 201,
    "emea_count": 98,
    "apac_count": 43
  },
  "traffic": {
    "all_domains_visits": 184200,
    "organic_percentage": 0.71,
    "paid_percentage": 0.29,
    "three_months_change": 0.12,
    "north_america_traffic_perc": 0.58,
    "europe_traffic_perc": 0.27
  },
  "technologies": {
    "has_matches": true,
    "technologies": ["Salesforce", "Segment"],
    "technologies_count": 2,
    "detection_count": 14
  },
  "funding": {
    "total_funding_amount": 42000000,
    "last_funding_stage": "Series B",
    "last_funding_date": "2025-09-15",
    "investors": ["Sequoia Capital", "Accel", "Index Ventures"]
  },
  "software": {
    "categories": ["Sales Engagement", "Revenue Intelligence"],
    "has_demo_request": true,
    "reviews_rating": 4.6,
    "reviews_count": 312
  }
}
```
{% endtab %}
{% endtabs %}

### Batch enrich

`POST /v1/enrich/batch`

```json
{
  "domains": ["acmecorp.io", "betalabs.com", "deltaplatform.io"],
  "blocks": ["firmographics", "hiring", "traffic"],
  "dynamic_config": {
    "technologies": {
      "technologies": ["Salesforce"]
    }
  }
}
```

### Subscribe to changes

`POST /v1/webhooks`

```json
{
  "event": "company.enrichment.updated",
  "url": "https://your-platform.com/webhooks/goodfit",
  "blocks": ["hiring", "funding", "traffic"]
}
```

***

## What's in each block

Here's a summary of what comes back. Click through to any block for the full schema.

| Block | Fields | Highlights |
| --- | ---: | --- |
| [firmographics](firmographics.md) | 48 | Name, HQ, headcount, revenue, B2B/B2C, SaaS, GTM model, IPO status, parent org, competitors |
| [hiring](hiring.md) | 52 | 13 department breakdowns, geo expansion, remote %, republished roles, role freshness |
| [team](team.md) | 37 | Department splits (count + %), regional distribution, outside-HQ signals |
| [team\_members](team-members.md) | 8 | **Dynamic:** query by department, seniority, country, keyword, tenure |
| [technologies](technologies.md) | 7 | **Dynamic:** detect any technology from website + job descriptions |
| [traffic](traffic.md) | 29 | Visits, rank, bounce rate, organic/paid, 7-region geo, 3-month velocity |
| [funding](funding.md) | 10 | Total raised, last round, investors, acquisitions |
| [jobs](jobs.md) | 8 | **Dynamic:** title/description keyword match with country filters |
| [predictive\_labels](predictive-labels.md) | 3 | **Dynamic:** GoodFit NLP classifiers — your labels, our models |
| [software](software.md) | 9 | G2/Capterra categories, reviews, demo/trial, pricing page |
| [glassdoor](glassdoor.md) | 10 | Employee reviews, CEO approval, interview difficulty |
| [company\_reviews](company-reviews.md) | 7 | **Dynamic:** keyword-matched Trustpilot reviews |
| [website\_performance](website-performance.md) | 14 | Lighthouse: speed, SEO, accessibility, Core Web Vitals |
| + 12 more blocks | 53 | Domain elements, pages, investments, localisations, ads, descriptions... |

***

## Proprietary intelligence

{% hint style="warning" %}
**These fields exist nowhere else.** They're generated by GoodFit's own NLP models that read and classify company websites:

* `is_b2b` / `is_b2c` + probability scores
* `is_saas` — SaaS detection from website + product signals
* `is_technology` — technology company classification
* `gtm_model` — Product-Led or Sales-Assisted
* `predictive_labels` — fully custom classifiers you define ("marketplace", "vertical SaaS", "agency")

No third-party database contains these. They require reading the actual website.
{% endhint %}

***

## Why this matters

{% hint style="info" %}
**One integration. Not five vendors.** Firmographics from LinkedIn. Traffic from Semrush. Tech detection from BuiltWith. Reviews from G2. Hiring data from Indeed. And classifications that only exist inside GoodFit — because we actually read the website with NLP models, not repackage someone else's database.
{% endhint %}
