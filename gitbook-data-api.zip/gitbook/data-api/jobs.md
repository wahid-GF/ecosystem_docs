# Jobs (Keyword Match)

{% hint style="warning" %}
**Dynamic — Configurable** · 8 fields · Source: LinkedIn Jobs, Indeed
{% endhint %}

Search a company's open roles by title keywords, description keywords, negative keywords, and country filters. Your ICP criteria, applied to the entire job market.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"onlyOpenJobs":true,"titleKeywords":["data engineer","analytics"],"descriptionKeywords":["dbt","snowflake"],"negativeTitleKeywords":["intern"],"negativeDescriptionKeywords":[],"countries":["United States","United Kingdom"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_count` | Number | Open roles matching criteria |
| `matched_percentage` | Percentage | % of all roles matching |
| `matched_countries` | Multipicklist | Countries where matches were found |
| `matched_keywords` | Multipicklist | Keywords that matched |
| `has_matches` | Boolean | Whether any matches exist |
| `sample_url` | String | Sample matching role URL |
| `last_posted_at` | Date | Most recent matching role date |
| `first_posted_at` | Date | Earliest matching role date |

***

## Example response

```json
{
  "matched_count": 8,
  "matched_percentage": 0.17,
  "has_matches": true,
  "matched_keywords": [
    "data engineer",
    "analytics"
  ],
  "matched_countries": [
    "United States",
    "United Kingdom"
  ],
  "last_posted_at": "2026-02-14"
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
