# Pages

{% hint style="warning" %}
**Dynamic — Configurable** · 5 fields · Source: GoodFit Crawler
{% endhint %}

Detect specific URL patterns on a company's website — /pricing, /api, /partners, /integrations, /careers.

***

## Configuration

Pass these parameters to customise the block output per query:

```json
{"urlPatterns":["/pricing","/api","/partners"]}
```

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `matched_patterns` | Multipicklist | URL patterns matched |
| `matched_urls` | Array | URLs with matches |
| `matched_count` | Number | Count of matching URLs |
| `has_matches` | Boolean | Whether matches exist |
| `sample_url` | String | Shortest matching URL |

***

## Example response

```json
{
  "has_matches": true,
  "matched_patterns": [
    "/pricing",
    "/api"
  ],
  "matched_count": 2,
  "sample_url": "https://acmecorp.io/pricing"
}
```

***

{% hint style="success" %}
**This is a Dynamic block.** Every parameter combination produces distinct data points. Use it as a sourcing filter (to find companies matching these criteria) or as an enrichment field (to learn this about a specific company).
{% endhint %}
