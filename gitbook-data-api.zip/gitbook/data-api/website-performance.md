# Website Performance

{% hint style="info" %}
**Core** · 14 fields · Source: Lighthouse
{% endhint %}

Google Lighthouse performance audit — speed, SEO, accessibility, Core Web Vitals.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `speed_score_label` | Picklist | Speed score label |
| `speed_score` | Number | Speed score |
| `speed` | Number | Speed metric |
| `seo_score` | Percentage | SEO score |
| `score` | Number | Overall Lighthouse score |
| `performance_score` | Percentage | Performance score |
| `best_practices_score` | Percentage | Best practices score |
| `accessibility_score` | Percentage | Accessibility score |
| `time_to_interactive` | Number | Time to interactive |
| `largest_contentful_paint` | Number | LCP |
| `first_contentful_paint` | Number | FCP |
| `first_input_delay` | Number | FID |
| `total_blocking_time` | Number | Total blocking time |
| `cumulative_layout_shift` | Number | CLS |

***

## Example response

```json
{
  "performance_score": 0.87,
  "seo_score": 0.92,
  "accessibility_score": 0.78,
  "largest_contentful_paint": 1240
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
