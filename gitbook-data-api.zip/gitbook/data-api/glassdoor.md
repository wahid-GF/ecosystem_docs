# Glassdoor

{% hint style="info" %}
**Core** · 10 fields · Source: Glassdoor
{% endhint %}

Employee sentiment signals — review ratings, CEO approval, interview experience, and difficulty scores.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `interviews_count` | Number | Interview review count |
| `reviews_count` | Number | Employee review count |
| `url` | String | Glassdoor profile URL |
| `ceo_approval_percentage` | Percentage | CEO approval % |
| `recommend_to_friend_percentage` | Percentage | Recommend to friend % |
| `reviews_rating` | Number | Overall rating |
| `interviews_positive_percentage` | Percentage | Positive interview % |
| `interviews_negative_percentage` | Percentage | Negative interview % |
| `interviews_neutral_percentage` | Percentage | Neutral interview % |
| `interviews_difficulty` | Number | Interview difficulty rating |

***

## Example response

```json
{
  "reviews_rating": 4.1,
  "ceo_approval_percentage": 0.82,
  "interviews_difficulty": 3.2,
  "recommend_to_friend_percentage": 0.78
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
