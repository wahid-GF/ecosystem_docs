# Ads

{% hint style="info" %}
**Core** · 1 fields · Source: Google Adwords
{% endhint %}

Estimated advertising spend from publicly accessible Google Adwords data.

***

## Schema

| Field | Type | Description |
| --- | --- | --- |
| `adwords_spend` | Currency | Estimated Adwords spend |

***

## Example response

```json
{
  "adwords_spend": 12400
}
```

***

{% hint style="info" %}
This block is available as both a **sourcing filter** and an **enrichment field**. Use it to define market criteria or to enrich individual companies.
{% endhint %}
