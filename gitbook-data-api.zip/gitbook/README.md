# Data API

**296 data attributes. 25 data blocks. 14+ live sources. Two capabilities.**

GoodFit's Data API exposes two core capabilities — **Account Sourcing** and **Enrichment** — powered by a shared layer of 25 data blocks. Every block is sourced from named, primary web sources. No repackaged databases. No mystery data.

***

## Capabilities

| Capability                                           | What it does                                                 | Endpoint           |
| ---------------------------------------------------- | ------------------------------------------------------------ | ------------------ |
| [**Account Sourcing**](data-api/account-sourcing.md) | Define a market using data block criteria. Receive qualified, continuously refreshed accounts. | `POST /v1/markets` |
| [**Enrichment**](data-api/enrichment.md)             | Pass a domain. Get back up to 296 attributes across 25 data blocks in one call. | `POST /v1/enrich`  |

Both capabilities draw from the same data blocks listed below. Use them as **sourcing filters** (to define which companies qualify) or as **enrichment fields** (to learn everything about a company).

***

## Data blocks at a glance

| Block               | Fields | Type        | Primary source                     |
| ------------------- | -----: | ----------- | ---------------------------------- |
| firmographics       |     48 | Core        | LinkedIn, Crunchbase, GoodFit NLP  |
| hiring              |     52 | Core        | LinkedIn Jobs, Indeed              |
| team                |     37 | Core        | LinkedIn                           |
| traffic             |     29 | Core        | Semrush                            |
| website\_performance |     14 | Core        | Lighthouse                         |
| funding             |     10 | Core        | Crunchbase, Dealroom               |
| glassdoor           |     10 | Core        | Glassdoor                          |
| software            |      9 | Core        | G2, Capterra                       |
| localisations       |      4 | Core        | GoodFit Crawler                    |
| reviews             |      3 | Core        | Trustpilot                         |
| website             |      3 | Core        | GoodFit Crawler                    |
| ads                 |      1 | Core        | Google Adwords                     |
| team\_members        |      8 | Dynamic | LinkedIn                           |
| jobs                |      8 | Dynamic | LinkedIn Jobs, Indeed              |
| technologies        |      7 | Dynamic | BuiltWith, SimilarTech             |
| company\_reviews     |      7 | Dynamic | Trustpilot                         |
| software\_reviews    |      7 | Dynamic | G2                                 |
| domain\_elements     |      9 | Dynamic | GoodFit Crawler                    |
| investments         |      9 | Dynamic | Crunchbase, Dealroom               |
| pages               |      5 | Dynamic | GoodFit Crawler                    |
| software\_features   |      4 | Dynamic | G2, Capterra                       |
| predictive\_labels   |      3 | Dynamic | GoodFit NLP                        |
| linkedin\_description |      2 | Dynamic | LinkedIn                           |
| website\_description |      2 | Dynamic | GoodFit Crawler                    |
| main\_page\_text      |      2 | Dynamic | GoodFit Crawler                    |

{% hint style="info" %}
**Core** blocks return the same fields for every company.

**Dynamic** blocks accept your parameters — keywords, countries, departments, technologies, rating filters — and return signals tailored to each configuration. Each parameter combination produces distinct data points. The effective attribute count per customer is significantly higher than 296.
{% endhint %}

***

## Data freshness

No data point older than 30 days. In practice, high-traffic entities refresh continuously. Different attributes update at different cadences depending on source availability and query frequency — but the end-user experience is near real-time.

| Source            | Refresh cadence               |
| ----------------- | ----------------------------- |
| LinkedIn profiles | Continuous for active queries |
| LinkedIn Jobs     | Daily                         |
| Semrush traffic   | Monthly                       |
| Crunchbase/Dealroom | Weekly                      |
| BuiltWith/SimilarTech | Weekly                    |
| G2/Capterra       | Weekly                        |
| Trustpilot        | Weekly                        |
| Glassdoor         | Weekly                        |
| Lighthouse        | Monthly                       |
| GoodFit NLP       | On crawl (continuous)         |

***

## Sources

Every data point traces to a named source. GoodFit indexes 14+ primary sources:

**Company & People:** LinkedIn, Crunchbase, Dealroom\
**Hiring:** LinkedIn Jobs, Indeed\
**Traffic & Web:** Semrush, Lighthouse (Google)\
**Technology:** BuiltWith, SimilarTech, GoodFit Web Crawler\
**Reviews & Software:** G2, Capterra, Trustpilot, Glassdoor\
**Advertising:** Google Adwords\
**Proprietary NLP:** GoodFit classification models (B2B/B2C, SaaS, GTM model, predictive labels)
